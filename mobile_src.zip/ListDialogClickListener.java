package kr.ac.gwnu.ar.ui;

public interface ListDialogClickListener {
	public void onClick(String item, int position);
}
